# Local Bridge Protocol Draft

This is a design contract only; no transport implementation is included yet.

Messages should be newline-delimited JSON, versioned, and exchanged only between the local game processes.

Example messages:

```json
{"version":1,"type":"hello","game":"rdr2"}
{"version":1,"type":"hello","game":"minecraft"}
{"version":1,"type":"block_place","x":10,"y":64,"z":-3,"block":"minecraft:oak_planks"}
{"version":1,"type":"block_break","x":10,"y":64,"z":-3}
{"version":1,"type":"inventory_update","items":[{"id":"minecraft:oak_planks","count":16}]}
```

## Required safeguards
- Validate every message and cap message size.
- Bind only to loopback/local IPC; do not expose a network listener.
- Reject unknown message versions and invalid block identifiers.
- Persist world changes safely and provide a reset/backup option.
