# Minecraft Companion Mod

Target: Minecraft Java Edition + Fabric (exact version must be selected and tested before compiling).

Responsibilities planned:
- Register custom bridge client.
- Exchange block and inventory events.
- Keep Minecraft-side item/block IDs canonical.
- Provide a debug screen for connection status.

This folder intentionally contains no fake compiled JAR. A real mod must be implemented against the selected Minecraft/Fabric APIs and tested in the target instance.
