# RDR2 Host Plugin

Target: RDR2 Story Mode with a compatible Ultimate ASI Loader setup.

Responsibilities planned:
- Spawn/represent classic Minecraft Steve.
- Detect safe building areas and render block placements.
- Handle local save data and horse-related interactions.
- Communicate with the Minecraft companion through the local bridge.

This folder contains no compiled ASI. Native hooks, player model/animation integration, and in-game validation are still required.
