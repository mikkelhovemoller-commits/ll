# Build Milestones

- [ ] Confirm exact Minecraft Java version and loader.
- [ ] Implement and compile the Fabric companion.
- [ ] Implement a secure local bridge.
- [ ] Implement RDR2 Story Mode plugin and Steve appearance.
- [ ] Add block placement/removal rendering.
- [ ] Add resource gathering, crafting, and inventory sync.
- [ ] Test horse interaction and Valentine spawn.
- [ ] Run preflight and verify a real gameplay screenshot.
- [ ] Publish only after the user explicitly approves the final listing.
