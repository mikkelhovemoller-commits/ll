# Gameplay Design

## Opening
- Spawn in Valentine, in the RDR2 Story Mode world.
- Player character: classic blocky Minecraft Steve, blue shirt and purple pants.
- First actions: explore town, mount a horse, collect resources, and place Minecraft blocks.

## Core systems
- **Block building:** place and break individual blocks where the host world allows.
- **Survival gathering:** gather wood and stone.
- **Inventory:** block/item slots and stack counts.
- **Crafting:** turn gathered resources into basic building blocks and tools.
- **Horse riding:** retain RDR2 horse controls as much as possible.

## Scope guardrails
- Single-player first.
- No RDR2 Online support.
- Do not redistribute RDR2 or Minecraft assets.
- Use assets from the player's own installed game copies where legally and technically appropriate.
