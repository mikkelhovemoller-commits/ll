# Wild West Minecraft — Starter Project

A single-player mashup concept: classic Minecraft Steve (blue shirt, purple pants) in the real Red Dead Redemption 2 world, starting in Valentine. Intended features: horse riding, resource gathering, crafting, inventory, and free block building.

## Important status
This is an **untested source starter**, not a finished or compiled mod. It does not replace either game, contain game assets, or install itself. The current chat does not have access to Melty's build/publish tools or your local game folders, so I cannot honestly claim this is built, tested, or published.

## Target architecture
- **RDR2 host:** a story-mode-only native plugin loaded through an Ultimate ASI Loader-compatible setup.
- **Minecraft companion:** a Fabric mod for Minecraft Java Edition.
- **Bridge:** a local message protocol that a future tested build can use to synchronize block placement, inventory, and resource events.
- **No online mode:** keep RDR2 use to Story Mode.

## Proposed first playable milestone
1. Start in Valentine.
2. Use a Steve-like player model/skin in the RDR2 world.
3. Place and remove Minecraft-style blocks.
4. Save placed blocks and inventory locally.
5. Add gathering/crafting and horse interaction after the first milestone is tested.

## What is missing before this can be called playable
- RDR2 model/animation integration for Steve.
- A verified RDR2 native plugin build and in-game testing.
- The Fabric mod compiled against the exact Minecraft/Fabric versions.
- A working bridge between both processes.
- A real gameplay screenshot and Melty preflight/publish workflow.

Do not use this starter as if it were a completed mod.
